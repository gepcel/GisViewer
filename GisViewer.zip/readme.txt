﻿GisViewer Lister plugin for Total Commander

1. What's this?
This is a lister plugin for Total Commander, to view ESRI shapefiles.

2. How to install?
    ● For this to work, you need first to install .Net Framework (>=4.5.2), and .Net Interface 1.4 for Total Commander (only need to install once). Links is provied at the end.
    ● Then install the plugin itself.

3. How to use?
Move the cursor to any of the collection files of a shapefile, view it like any other lister. It can properly tell if a file belongs to a shapefile or just a single file. So try giving this a high order at the lister list.

Accepted files: .shp, .shx, .prj, .dbf, .sbn, .sbx, .shp.xml

4. Contact
Email: wayangel@outlook.com

5. Links:
GisViewer: https://github.com/gepcel/GisViewer
Official website of .NET: https://www.microsoft.com/net
Official website of .Net Interface 1.4 for Total Commander: https://sourceforge.net/projects/tcdotnetinterface/
You can also download and install the interface from: https://github.com/gepcel/GisViewer